#include <Wire.h>
#include <Adafruit_TinyUSB.h>
#include <MIDI.h>
#include "StringSensorModule.h"
#include "Config.h"

Adafruit_USBD_MIDI usb_midi;
MIDI_CREATE_INSTANCE(Adafruit_USBD_MIDI, usb_midi, MIDI);

StringSensorModule stringModule;

void handleNoteOn(uint8_t note, uint8_t vel) {
    MIDI.sendNoteOn(note, vel, MIDI_CHANNEL);
}

void handleNoteOff(uint8_t note) {
    MIDI.sendNoteOff(note, 0, MIDI_CHANNEL);
}

void handleModulation(uint8_t value) {
    MIDI.sendControlChange(1, value, MIDI_CHANNEL);  // CC1 = mod wheel
}

void setup() {
    Serial.begin(115200);
    delay(10);

    Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN);
    usb_midi.begin();

    MIDI.begin(MIDI_CHANNEL_OMNI);
    Serial.println("[MASTER] MIDI USB inicializado.");

    stringModule.begin(SLAVE_ADDR, Wire);
    stringModule.setNoteCallbacks(handleNoteOn, handleNoteOff, handleModulation);
}

void loop() {
    static uint32_t lastUpdate = 0;
    uint32_t now = millis();
    if (now - lastUpdate >= REQUEST_INTERVAL_MS) {
        lastUpdate = now;
        stringModule.update();
    }
}
